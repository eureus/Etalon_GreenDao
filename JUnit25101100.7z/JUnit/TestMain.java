import org.junit.*;
//import junit.framework.Assert;
import junit.runner.Version;
import static org.junit.Assert.assertEquals;


public class TestMain
{
	private MathFunc math; 

	public static void main(String [] args)
	{
	System.out.println("JUnit version is: " + Version.id());
	}

	@Before
	public void init() {
           math = new MathFunc(); 
    	   System.out.println("Inside init");

       }

	@After
	public void tearDown() {math = null; }

	@Test
	public void calls()
	{
		assertEquals(0, 0); // math.getCalls()); 

	//	math.factorial(1);
	//	assertEquals(1, math.getCalls()); 

	//	math.factorial(1);
	//	assertEquals(2, math.getCalls()); 

	} // end calls


} //