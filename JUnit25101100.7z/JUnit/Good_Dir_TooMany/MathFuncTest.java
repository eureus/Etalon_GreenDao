import org.junit.*;
//import junit.framework.Assert;
import junit.runner.Version;
import static org.junit.Assert.assertEquals;
import org.junit.runner.*;

public class MathFuncTest
{
	private MathFunc math; 


	public static void main(String[] args) throws Exception {
        JUnitCore runner = new JUnitCore();
        Result result = runner.run(MathFuncTest.class);
        System.out.println("run tests: " + result.getRunCount());
        System.out.println("failed tests: " + result.getFailureCount());
        System.out.println("ignored tests: " + result.getIgnoreCount());
        System.out.println("success: " + result.wasSuccessful());
    }

	@Before
	public void init() {math = new MathFunc(); }


	@After
	public void tearDown() {math = null; }

	@Test
	public void calls()
	{
		assertEquals(0, math.getCalls()); 

		math.factorial(1);
		assertEquals(1, math.getCalls()); 

		math.factorial(1);
		assertEquals(2, math.getCalls()); 

	} // end calls


} // end MathFuncTest

