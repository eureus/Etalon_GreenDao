import junit.runner.Version;


public class TestMain
{
	public static void main(String [] args)
	{
	System.out.println("JUnit version is: " + Version.id());
	}
} //