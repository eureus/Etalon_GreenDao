// http://www.javenue.info/post/19
public class MathFunc
{
  int calls; 

	public int getCalls()
	{
	  return calls;
	} // end getCalls

	public long factorial (int number)
	{
	 	calls ++;
		if (number < 0)
			throw new IllegalArgumentException(); 

		long result = 1;
		if (number > 1) 
		{
			for (int i=1; i <=number; i++)
			{
				result = result * i;
			} // end for
		} // end if (number > 1) 
		return result; 

	} // end factorial

	public long plus(int num1, int num2)
	{
		calls++;
		return num1 + num2; 	             	
	} // end plus

} // end MathFunc